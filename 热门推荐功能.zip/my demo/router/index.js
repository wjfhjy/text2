/**
 * 首页子应用（首页路由）
 */

 const express = require('express')
 const article = require('../middleware/article')
 
 
 // 首页子应用
 const indexApp = express()
 
 indexApp.use(auth.getUser)
 
 // 加载首页页面
 indexApp.get('/', [article.getHot], (req, res) => {
    res.render('index',{hots:req.hots})
 })
 
 module.exports = indexApp