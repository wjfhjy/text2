class User{
    constructor(name,pass){
        this.name=name;
        this.pass=pass;
    }
}
module.exports = User;