var express = require('express');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('task1');
});
router.post('/',(req,res)=>{
  let name=req.body.name;
  let pass=req.body.pass;
  if(req.session.user !=undefined && name==req.session.user.name
    &&pass==req.session.user.pass)
{
  res.send("success");
}else{
  res.send("fail");

}}) 

module.exports = router;