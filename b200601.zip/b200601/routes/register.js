var express = require('express');
var router = express.Router();
let User = require('./bean/user');

router.get('/', function(req, res ,next) {
    res.render('register');
  });
router.post('/', function(req,res) {
    let user=new User(req.body.name,req.body.pass);
    console.log(user);
    req.session.user=user;
    res.send("register success");
})
module.exports=router;

