let express=require('express');
let router=express.Router()
let fs=require('fs');

let data=new Array();


/*class User{
    constructor(name,s1,s2,s3){
        this.name=name,
        this.s1=s1,
        this.s2=s2,
        this.s3=s3,
        this.amount=Number(parseInt(this.s1)+parseInt(this.s2)+parseInt(this.s3))

    }
}*/
fs.readFile(__dirname+'/bean/s.json',{encoding:'utf-8'},(err,d)=>{
    if(err){
        console.log(err);
    }else{
        data=JSON.parse(d)//this指的是当前de
   
    
    }
})


router.get('/',(req,res,next)=>{//get后面变成:text 然后断点使用 req.params就可以查看传过来的参数
    res.render('index',{detail:data})
 
 })
/*router.post('/index',(req,res)=>{
    data.unshift(new User(req.body.name,req.body.s1,req.body.s2,req.body.s3))
    res.render('index',{detail:data})
})*/
router.get('/del/:id',(req,res)=>{
    delete data[req.params.id]
    res.redirect('/')
    })



router.get('/update/:id',(req,res)=>{
   res.render('add',{id:req.params.id,obj:data[req.params.id]})
})
router.get('/addpage',(req,res)=>{
    res.render('add',{obj:{},id:''})
})


router.post('/add',(req,res)=>{
 let obj=   {
        name:req.body.user,//这里面的name对应html的value值 
        s1:req.body.s1,
        s2:req.body.s2,
        s3:req.body.s3
    }
    if(req.body.id!=undefined&&req.body.id!=""){
        data[req.body.id]=obj;
    }else{
        data.unshift(obj)
    }
   //将里面的值添加到数组中去
    //添加完以后然后重新跳到页面中去
    res.redirect('/');
})



module.exports=router;

//res.redirecty('/text')这样子就会跳转某一个路由去 叫做重定向

//router.get('/text',()=>{
//会跳转到这个路由
//})
