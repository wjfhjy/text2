const { fstat } = require("fs");
var fs=require('fs');
fs.readFile(__dirname+'/bean/s.json',(err,data)=>{
if(err){
    console.log(err);
}else{
    console.log(data.toString());
}
})