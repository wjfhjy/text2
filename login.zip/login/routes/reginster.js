let express=require('express');
let router=express.Router();
let User=require('./bean/user')
router.get('/',(req,res)=>{
res.render('reginster')
});
router.post('/',(req,res)=>{
    
let user=new User(req.body.name,req.body.password)

req.session.user=user;
res.send('OK')
})
module.exports=router;