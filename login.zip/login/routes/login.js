let express=require('express');
let router=express.Router();
router.get('/login',(req,res)=>{
res.render('login')
})
router.post('/login',(req,res)=>{
let name=req.body.name;
let pass=req.body.pass;
if(req.session.user!=undefined&&name==req.session.user.name&&pass==req.session.user.pass){
    res.send('成功')
}else{
    res.send('失败')
}
})

module.exports=router;
