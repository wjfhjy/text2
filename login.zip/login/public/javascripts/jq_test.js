 $('#nextpage').click(function(){
        //请求服务器，拿到下一页的数据
        //这里相当于form表单
        $.ajax({
            type:'post',//请求方式
            url:'/nextpage',//获取路由路径 
            
            //如果请求成功了就可以执行这个函数，就可以输出post里面的json,负责接受index里post方法里面穿过来的参数
            success:function(data){
                
                if(data!=''&&data!=undefined){
              
                document.getElementById("showdata").innerHTML=
                
                 data.map((i,ind)=>
                    `
                    
                    <tr>
                    <td>${i.name}</td>
                    <td>${i.s1}</td>
                    <td>${i.s2}</td>
                    <td>${i.s3}</td>
                    <td></td>   
                <td><input type="button" data-id=${ind} class="del_button" value="删除"/></td>
                <td><input type="button" data-id=${ind} class="upd_button" value="修改"/></td>
                </tr>
                
                    `
                  )
                }
                
            }
        
                 //用map可以让等式成立，因为map可以返回数组
            
                
            }
        
    )
})






   